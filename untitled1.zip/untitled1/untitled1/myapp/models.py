from django.db import models


class Product(models.Model):
    product_name = models.CharField(max_length=200)
    price = models.IntegerField(default=0)
    category = models.CharField(max_length=200)
    quantity = models.IntegerField(default=1)
    purchase_date = models.DateField()
    expiry_date = models.DateField()

    def __str__(self):
        return self.product_name + self.category

    def __int__(self):
        return self.price + self.quantity

    def __expiry_date__(self):
        return self.expiry_date

    def __purchase_date__(self):
        return self.purchase_date



