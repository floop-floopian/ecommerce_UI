from django.shortcuts import render
from .models import Product
import re
import datetime


def index(request):
    return render(request, 'front_index.html',)


def show(request):
    return render(request, 'front_index.html', {'product': Product})


def product(request):
    if request:
        global bdgt
        ip = request.POST['Price']
        bdgt = int(ip)
        global best_product
        best_product = Product.objects.filter(Price=bdgt)

    else:
        return render(request, 'front_index.html', {'err_m': "Error"})

    return render(request, 'front_index.html', {'product': best_product})


def category(request):
    if request:
        global cat
        ip = request.POST['Category']
        cat = str(ip)
        global best_product
        best_product = Product.objects.filter(Category=cat)

    else:
        return render(request, 'front_index.html', {'err_m': "Error"})

    return render(request, 'front_index.html', {'product': cat})
