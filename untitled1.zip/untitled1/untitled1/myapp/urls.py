from django.conf.urls import url
from . import views

app_name = 'myapp'

urlpatterns = [
    url(r'^$', views.index, name="index"),
    url(r'^show', views.show, name="show"),
    url(r'^budget', views.product, name="product"),
    url(r'^category', views.category, name="category"),
]